#!/usr/bin/bash

exec ./launch_chffrplus.sh
