# Developing a car brand port

A brand port is a port of openpilot to a substantially new car brand or platform within a brand.

Here's an example of one: https://github.com/commaai/openpilot/pull/23331.
