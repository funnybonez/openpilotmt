# Developing a car model port

A model port is a port of openpilot to a new car model within an already supported brand. Model ports are easier than brand ports because the car's existing APIs are already known.

Here's an example of one: https://github.com/commaai/openpilot/pull/30672/.
