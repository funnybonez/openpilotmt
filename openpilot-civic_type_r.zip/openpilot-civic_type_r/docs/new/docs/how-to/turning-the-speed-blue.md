This section is for how-to's on common workflows.

They'll be like this blog post we wrote:
https://blog.comma.ai/turning-the-speed-blue/
