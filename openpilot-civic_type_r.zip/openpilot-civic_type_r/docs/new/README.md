This is the source for a new https://docs.comma.ai. It's not hosted anywhere yet, but it's easy to run locally.

https://www.mkdocs.org/getting-started/

```
pip install mkdocs mkdocs-terminal
mkdocs serve
```

inspiration:
* https://rerun.io/docs/
* https://docs.expo.dev/
